﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryAPI.Exceptions
{
    public class NullValueException:Exception
    {
        public NullValueException(string Message) : base(Message) { }
    }
}
