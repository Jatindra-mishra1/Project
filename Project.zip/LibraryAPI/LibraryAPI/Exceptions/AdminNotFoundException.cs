﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryAPI.Exceptions
{
    public class AdminNotFoundException:Exception
    {
        public AdminNotFoundException(string Message) : base(Message) { }
    }
}
