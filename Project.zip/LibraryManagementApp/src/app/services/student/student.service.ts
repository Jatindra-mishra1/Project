import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from 'src/app/Models/Student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  
  static count:number;
  constructor(private http:HttpClient){  }
  readonly APIurl="https://localhost:44315/api/User/";
  getStudentList():Observable<Student[]>{
    console.log("Entered Stuent service get list!");
    
    return this.http.get<Student[]>(this.APIurl+'students')
  }
  addStudent(student:Student){
    this.http.post<Student>(this.APIurl+'add_student',student).subscribe(data=>{
      console.log(data);
      StudentService.count++;
    });
  }
  deleteStudent(student:Student){
    this.http.delete(this.APIurl+'delete_student?StudentId='+student.studentId).subscribe(data=>{
      console.log(data);
    });
  }
  updateStudent(studentId: number, student: Student) {
    this.http.put<Student>(this.APIurl+'update_student?StudentId='+studentId,student).subscribe(data=>{
      console.log(data);
    });
  }
}
