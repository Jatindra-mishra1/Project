import { HttpClient } from '@angular/common/http';
import { isNull } from '@angular/compiler/src/output/output_ast';
import { Injectable } from '@angular/core';
import { DefaultComponent } from 'src/app/default/default/default.component';
import { Admin } from 'src/app/Models/Admin';
import { LogInModel } from 'src/app/Models/LogInModel';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  readonly APIurl="https://localhost:44315/api/Login";
  isAuthenticated=false;
  Admin:Admin|null;
  temp:Admin;
  result:boolean|false;
  authenticate(signInData:LogInModel, component: DefaultComponent){
    console.log(signInData);
    this.http.post<Admin>(this.APIurl+'/Check',signInData).subscribe(data =>{
      this.temp=data;
      if(data!=null){
      this.result=true;
      this.Admin=this.temp;
      }
    });
    console.log(this.Admin);
    if(this.Admin!=null){
      component.isAuthorized=true;
      component.login=false;
      component.Admin=this.Admin;
    }
      return this.Admin;
  }

  constructor(private http:HttpClient) { }
}
