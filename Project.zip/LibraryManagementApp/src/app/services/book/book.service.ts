import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { Observable } from 'rxjs';
import { Book } from 'src/app/Models/Book';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  return(bookId: number) {
    console.log(bookId);
    this.http.post<string>(this.APIurl+'return_book?BookId='+bookId,null).subscribe(data=>{
      console.log(data);
    });
  }
  issueBook(bookId:number,Id:number) {
    this.http.post<string>(this.APIurl+'issue_book?BookId='+bookId+'&Id='+Id,null).subscribe(data=>{
      console.log(data);
    });
  }
  updateBook(book: Book) {
    this.http.put<Book>(this.APIurl+'update_book?BookId='+book.bookId,book).subscribe(data=>{
      console.log(data);
    });
  }
  deleteBook(book: Book) {
    this.http.delete(this.APIurl+'delete_book?Id='+book.bookId.toString).subscribe(data=>{
      console.log(data);
    });
  }
  readonly APIurl="https://localhost:44315/api/Book/";
  getBookList():Observable<Book[]>{
    return this.http.get<Book[]>(this.APIurl+'books')
  }
  addBook(book:Book){
    book.issuedTo="";
    console.log(book);
    this.http.post(this.APIurl+'add_book',book).subscribe(data=>{
      console.log(data);
    });
  }
  constructor(private http:HttpClient) { }
}
