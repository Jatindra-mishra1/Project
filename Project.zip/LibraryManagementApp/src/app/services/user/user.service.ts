import { Injectable } from '@angular/core';
import { StudentService } from '../student/student.service';
import { TeacherService } from '../teacher/teacher.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  scount=0;
  tcount=0;
  constructor(private studentservice:StudentService,private teacherservice:TeacherService) { 
    this.scount=StudentService.count;
    this.tcount=TeacherService.count;
  }
  count(){
    return this.scount+this.tcount;
  }
}
