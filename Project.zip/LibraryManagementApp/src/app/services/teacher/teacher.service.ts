import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Teacher } from 'src/app/Models/Teacher';

@Injectable({
  providedIn: 'root'
})
export class TeacherService {
  
  static count:number;
  constructor(private http:HttpClient) { }
  readonly APIurl="https://localhost:44315/api/User/";
  getTeacherList():Observable<Teacher[]>{
    return this.http.get<Teacher[]>(this.APIurl+'teachers')
  }
  addTeacher(teacher:Teacher){
    this.http.post<Teacher>(this.APIurl+'add_teacher',teacher).subscribe(data=>{
      console.log(data);
      TeacherService.count++;
    });
  }
  deleteTeacher(teacher:Teacher){
    this.http.delete(this.APIurl+'delete_teacher?TeacherId='+teacher.teacherId).subscribe(data=>{
      console.log(data);
    });
  }
  updateTeacher(teacherId: number,teacher:Teacher) {
    this.http.put<Teacher>(this.APIurl+'update_teacher?TeacherId='+teacherId,teacher).subscribe(data=>{
      console.log(data);
    });
  }
}
