import { Component, OnInit } from '@angular/core';
import { AnimationDurations } from '@angular/material/core';
import { Admin } from 'src/app/Models/Admin';

@Component({
  selector: 'app-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.css']
})
export class DefaultComponent implements OnInit {
  login:boolean;
  isAuthorized:boolean;
  Admin:Admin|null;
  constructor() {
    this.login=true;
    this.isAuthorized=false;
   }

  ngOnInit(): void {
  }

}
