import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { DashboardComponent } from './Modules/dashboard/dashboard.component';
import { LoginComponent } from './Modules/login/login.component';
import { BooksComponent } from './Modules/books/books.component';
import { AddstudentComponent } from './Modules/addstudent/addstudent.component';
import { AddteacherComponent } from './Modules/addteacher/addteacher.component';
import { EBooksComponent } from './Modules/e-books/e-books.component';
import { IssueReturnComponent } from './Modules/issue-return/issue-return.component';
import { NotificationsComponent } from './Modules/notifications/notifications.component';
import { OtherDetailsComponent } from './Modules/other-details/other-details.component';
import { UsersComponent } from './Modules/users/users.component';
import { SettingsComponent } from './Modules/settings/settings.component';
import { ViewstudentsComponent } from './Modules/viewstudents/viewstudents.component';
import { ViewteachersComponent } from './Modules/viewteachers/viewteachers.component';
import { SharedComponent } from './shared/shared/shared.component';
import { DefaultComponent } from './default/default/default.component';
import { FormsModule } from '@angular/forms';
import {MatTableModule} from '@angular/material/table';
import {MatIconModule} from '@angular/material/icon';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatGridListModule} from '@angular/material/grid-list' ;

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
    BooksComponent,
    AddstudentComponent,
    AddteacherComponent,
    EBooksComponent,
    IssueReturnComponent,
    NotificationsComponent,
    OtherDetailsComponent,
    UsersComponent,
    SettingsComponent,
    ViewstudentsComponent,
    ViewteachersComponent,
    SharedComponent,
    DefaultComponent
  ],
  imports: [
    BrowserModule,
    MatTableModule,
    MatIconModule,
    FormsModule,
    HttpClientModule,
    MatGridListModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
