import { Component, OnInit } from '@angular/core';
import { DefaultComponent } from 'src/app/default/default/default.component';
import { LoginComponent } from 'src/app/Modules/login/login.component';

@Component({
  selector: 'app-shared',
  templateUrl: './shared.component.html',
  styleUrls: ['./shared.component.css']
})
export class SharedComponent implements OnInit {
  refteacher() {
    this.viewteachers=false;
    this.viewteachers=true;
  }
  refstudent() {
    this.viewstudents=false;
    this.viewstudents=true;
  }
  settings=false;
  dashboard=true;
  users=false;
  books=false;
  ebooks=false;
  issuereturn=false;
  details=false;
  addteachers=false;
  addstudents=false;
  viewstudents=false;
  viewteachers=false;
  notifications=false;
  login=false;
  constructor(private component:DefaultComponent) { }

  ngOnInit(): void {
  }
  logout(){
    this.component.isAuthorized=false;
    this.component.login=true;
  }

}
