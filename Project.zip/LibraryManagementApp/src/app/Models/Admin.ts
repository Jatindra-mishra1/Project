export class Admin{
    private name:string;
    private id:string;
    public email:string;
    public userName:string;
    private password:string;
    private phone:string;
    private address:string;
    constructor(name:string,id:string,email:string,userName:string,password:string,phone:string,address:string){
        this.name=name;
        this.id=id;
        this.email=email;
        this.userName=userName;
        this.password=password;
        this.phone=phone;
        this.address=address;
    }
    getName(){
        return this.name;
    }
    getEmail(){
        return this.email;
    }
    getId(){
        return this.id;
    }
    getUserName(){
        return this.userName;
    }
    getPhone(){
        return this.phone;
    }
    getAddress(){
        return this.address;
    }

}