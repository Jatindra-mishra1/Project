export class Teacher{
    public teacherId:number;
    public teacherName:string;
    public email:string;
    public userName:string;
    public password:string;
    public phone:string;
    public address:string;
}