export class Student{
    public studentId:number;
    public studentName:string;
    public email:string;
    public userName:string;
    public password:string;
    public phone:string;
    public address:string;
}