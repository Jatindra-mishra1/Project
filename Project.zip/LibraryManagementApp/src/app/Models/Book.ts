export class Book{
    public bookId:number;
    public bookName:string;
    public author:string;
    public issuedTo:string;
    public bookType:string;
    
}