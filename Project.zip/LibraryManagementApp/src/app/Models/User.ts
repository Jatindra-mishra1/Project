export class User{
    public name:string;
    public id:string;
    public email:string;
    public userName:string;
    public password:string;
    public phone:string;
    public address:string;
}