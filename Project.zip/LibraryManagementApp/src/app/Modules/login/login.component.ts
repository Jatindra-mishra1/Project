import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DefaultComponent } from 'src/app/default/default/default.component';
import { Admin } from 'src/app/Models/Admin';
import { AuthenticationService } from 'src/app/services/authentication/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email="";
  password="";
  res:boolean;
  Admin:Admin|null;
  constructor(private component:DefaultComponent,private service:AuthenticationService) {this.res=false; this.Admin=null; }
  Login(form:NgForm)
    {
      console.log(form.value);
      if(form.value.email != ''){
    this.Admin=this.service.authenticate(form.value,this.component);
    this.service.Admin=null;
    form.resetForm();
      }
    if(this.Admin== null)
      this.res=true;
  }
  ngOnInit(): void {
  }

}
