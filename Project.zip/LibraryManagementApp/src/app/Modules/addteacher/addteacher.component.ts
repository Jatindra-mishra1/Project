import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { TeacherService } from 'src/app/services/teacher/teacher.service';

@Component({
  selector: 'app-addteacher',
  templateUrl: './addteacher.component.html',
  styleUrls: ['./addteacher.component.css']
})
export class AddteacherComponent implements OnInit {
  ngOnInit(): void {
  }
  constructor(private service:TeacherService) {this.res=false; }
  res:boolean;
  onSubmit(form:NgForm){
    console.log(form.value.password+" "+form.value.email);
    if(form.value.password==form.value.cpassword)
        this.service.addTeacher(form.value);
    else
      this.res=true;
    form.resetForm();
  }
  

}
