import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { StudentService } from 'src/app/services/student/student.service';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {

  constructor(private service:StudentService) {this.res=false; }
  res:boolean;
  ngOnInit(): void {
  }
  onSubmit(form:NgForm){
    console.log(form.value.password+" "+form.value.email);
    if(form.value.password==form.value.cpassword)
        this.service.addStudent(form.value);
        else
          this.res=true;
    form.resetForm();
  }
}
