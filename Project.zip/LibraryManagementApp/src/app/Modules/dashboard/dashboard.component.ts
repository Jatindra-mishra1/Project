import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user/user.service';
import { ViewstudentsComponent } from '../viewstudents/viewstudents.component';
import { ViewteachersComponent } from '../viewteachers/viewteachers.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  date:string;
  time:string;
  count:string;
  constructor(private user:UserService) { 
    this.date=new Date().toLocaleDateString().toString();
    this.time=new Date().toLocaleTimeString().toString();
    this.count=user.count().toString();
  }

  ngOnInit(): void {
  }

}
