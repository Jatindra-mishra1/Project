import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Teacher } from 'src/app/Models/Teacher';
import { TeacherService } from 'src/app/services/teacher/teacher.service';
import { SharedComponent } from 'src/app/shared/shared/shared.component';

@Component({
  selector: 'app-viewteachers',
  templateUrl: './viewteachers.component.html',
  styleUrls: ['./viewteachers.component.css']
})
export class ViewteachersComponent implements OnInit {

  dataSource:MatTableDataSource<Teacher>;
  Columns:string[]=['id','name','username','email','phone','address','action'];
  constructor(private service:TeacherService,private sservice:SharedComponent) { this.count=0; }
  count:number;
  res=false;
  teacherId:number;
  ngOnInit(): void {
    this.refTeacherList();
  }
  onDelete(teacher:Teacher){
    this.service.deleteTeacher(teacher);
    this.refTeacherList();
  }
  refTeacherList(){
    this.service.getTeacherList().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data);
    });
    this.sservice.refteacher();
  }
  selectId(Id:number){
      this.teacherId=Id;
  }
  onUpdate(teacher:NgForm){
    this.service.updateTeacher(this.teacherId,teacher.value);
    this.sservice.viewstudents=false;
    this.sservice.viewstudents=true;
  }
}
