import { Component, OnInit } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { BookService } from 'src/app/services/book/book.service';

@Component({
  selector: 'app-issue-return',
  templateUrl: './issue-return.component.html',
  styleUrls: ['./issue-return.component.css']
})
export class IssueReturnComponent implements OnInit {

  constructor(private service:BookService) { }

  ngOnInit(): void {
  }
  issue(bookId:NgModel,Id:NgModel){
    this.service.issueBook(bookId.value,Id.value);
  }
  return(bookId:NgModel){
    this.service.return(bookId.value);
  }

}
