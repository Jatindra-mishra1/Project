import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Student } from 'src/app/Models/Student';
import { StudentService } from 'src/app/services/student/student.service';
import { SharedComponent } from 'src/app/shared/shared/shared.component';

@Component({
  selector: 'app-viewstudents',
  templateUrl: './viewstudents.component.html',
  styleUrls: ['./viewstudents.component.css']
})
export class ViewstudentsComponent implements OnInit {
  dataSource:MatTableDataSource<Student>;
  Columns:string[]=['id','name','username','email','phone','address','action'];
  constructor(private service:StudentService,private sservice:SharedComponent) { }
  count=0;
  res=false;
  studentId:number;
  ngOnInit(): void {
    this.refStudentList();
  }
  selectId(Id:number){
    this.studentId=Id;
  }
  onDelete(student:Student){
    this.service.deleteStudent(student);
    this.refStudentList();
  }
  onUpdate(student:NgForm){
    this.service.updateStudent(this.studentId,student.value);
    this.refStudentList();
  }
  refStudentList(){
    this.service.getStudentList().subscribe(data=>{
      this.dataSource=new MatTableDataSource(data);
    });
    this.sservice.refstudent();
    
  }
}

