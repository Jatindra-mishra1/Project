import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Book } from 'src/app/Models/Book';
import { BookService } from 'src/app/services/book/book.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  dataSource:MatTableDataSource<Book>;
  Columns:string[]=['id','title','author','issuedTo','type','action'];
  constructor(private service:BookService) { 
    this.count=0;
  }
  count=0;
  ngOnInit(): void {
    this.refBookList();
  }
  onDelete(book:Book){
    this.service.deleteBook(book);
    this.refBookList();
  }
  onSubmit(form:NgForm){
    console.log(form.value);
    this.service.addBook(form.value);
  }
  onUpdate(form:NgForm){
    this.service.updateBook(form.value);
  }
  refBookList(){
    this.service.getBookList().subscribe(data=>{
      this.dataSource=new MatTableDataSource<Book>(data);
    });
  }

}
